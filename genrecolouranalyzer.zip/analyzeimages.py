##########################
# run getimages.py first!#
##########################

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d
from PIL import Image
import os
import colorthief as ct

genre_ids = [  # should be same as the one in getimages.py!
    4,  # fighting
    5,  # shooter
    8,  # platformer
    10,  # racing
    12,  # RPG
    36  # MOBA
]

directory = 'images'


def generateColorList(genre_id):
    for file in os.scandir(directory + "/" + str(genre_id)):
        if (file.path.endswith(".jpg") or file.path.endswith(".png")) and file.is_file():
            image = ct.ColorThief(file.path)
            palette = image.get_color()
            colours_list.append(palette)
            print(genre, os.path.basename(file.path), palette)


def getNameFromGenreID(genre_id):
    if genre_id == 4:
        output = "fighting game"
    elif genre_id == 5:
        output = "shooter game"
    elif genre_id == 8:
        output = "platforming"
    elif genre_id == 10:
        output = "racing game"
    elif genre_id == 12:
        output = "role playing game"
    elif genre_id == 36:
        output = "MOBA"
    return output


#  main
for genre in genre_ids:
    #  for plotting
    xlist = []
    ylist = []
    zlist = []
    clist = []
    colours_list = []

    ax = plt.axes(projection='3d')

    generateColorList(genre)
    for i in range(0, len(colours_list)):
        x = colours_list[i][0]
        xlist.append(x)
        y = colours_list[i][1]
        ylist.append(y)
        z = colours_list[i][2]
        zlist.append(z)
        c = (x / 255, y / 255, z / 255)
        clist.append(c)
    ax.scatter(xlist, ylist, zlist, c=clist, s=125)
    plt.title("Most dominant colours in the " + getNameFromGenreID(genre) + " genre.")
    plt.show()
